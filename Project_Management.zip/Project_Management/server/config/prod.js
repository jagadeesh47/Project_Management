module.exports = {
    MongoURI: process.env.MongoURI,
    JWT_KEY: process.env.JWT_KEY
}